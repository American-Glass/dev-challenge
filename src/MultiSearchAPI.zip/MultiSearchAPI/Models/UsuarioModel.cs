﻿namespace MultiSearchAPI.Models
{
    public class UsuarioModel
    {
        public int id { get; set; }

        public string name { get; set; }
    }
}
