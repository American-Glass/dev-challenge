﻿using Microsoft.AspNetCore.Mvc;
using MultiSearchAPI.Models;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MultiSearchAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EquipmentController : ControllerBase
    {
     

        // GET api/<EquipmentController>/5
        [HttpGet]
        public String Get()
        {
            Console.Write("Get Get");
            return "Value sadasd";
        }

        // GET api/<EquipmentController>/5
        [HttpGet("{id}")]
        public Equipment Get(int id)
        {
            return new Equipment();
        }

        [HttpGet("{value}")]

        public List<Equipment>? EquipmentFilter(String value)
        {
            return new List<Equipment>();
        }
    }
}
