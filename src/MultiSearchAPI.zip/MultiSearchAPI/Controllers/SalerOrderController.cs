﻿using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MultiSearchAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SalerOrderController : ControllerBase
    {
   

        // GET api/<SalerOrderController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // GET api/<SalerOrderController>/5
        [HttpGet("{name}")]
        public string GetbyName(String name)
        {
            return "value";
        }


    }
}
